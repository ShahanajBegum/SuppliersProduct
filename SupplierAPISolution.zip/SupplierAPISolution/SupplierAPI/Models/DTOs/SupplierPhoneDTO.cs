﻿namespace SupplierAPI.Models.DTOs
{
    public class SupplierPhoneDTO
    {
        public int Id { get; set; }
        public string Phone { get; set; }
    }
}
